# Verification spike results

Fill in one row per check, with the date, device or environment, and what you saw. Delete the example row.

| Check | Hypothesis | Result | Date | Notes |
| --- | --- | --- | --- | --- |
| A1 | A port cannot be made public by devcontainer config alone | | | |
| A2 | An anonymous phone loads the forwarded URL with no interstitial | | | |
| A3 | The QR origin built from Codespaces env vars opens from outside | | | |
| A4 | WebSockets reconnect in under 5 seconds after a drop | | | |
| A5 | Start scripts are idempotent and survive stop and start | | | |
| A6 | A private admin port can issue the first host credential | | | |
| A6b | The Open Trivia Database is reachable from a Codespace | | | |
| A7 | Web Cast sender is unavailable on iOS browsers | | | |
| A8 | A registered custom receiver loads from a stable HTTPS URL | | | |
| A9 | Pairing token exchange yields a read-only display credential | | | |
| A10 | A phone can play and cast at the same time (Android Chrome) | | | |
| A11 | The display renders smoothly on a Chromecast-class device | | | |
